# BookMark & History Search

Chrome Extention

![利用イメージ](screenshot/chrome.png)


検索ボックスからブックマークと履歴を検索するシンプルな拡張機能です

[Chrome Extention Store](https://chromewebstore.google.com/detail/fjlafgfjokeemphjaeapcmfmcicehahi?utm_source=item-share-cb)
