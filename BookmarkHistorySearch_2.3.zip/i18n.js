// js/i18n.js — MV3対応 i18nヘルパー（applyLocale/init/DOM適用）
const I18N = (() => {
  const SUPPORTED = ["en", "ja"];
  const STORAGE_KEY = "langOverride"; // chrome.storage.sync に保存するキー

  let currentLocale = "en";
  let messages = {};
  let currentT = (k, f = "") => messages[k]?.message ?? (f || k);

  function normalizeLocale(lang) {
    if (!lang) return "en";
    const l = String(lang).toLowerCase();
    if (l.startsWith("ja")) return "ja";
    return "en";
  }

  function resolveAutoLocale() {
    const langs = navigator.languages?.length
      ? navigator.languages
      : [navigator.language || "en"];
    for (const l of langs) {
      const n = normalizeLocale(l);
      if (SUPPORTED.includes(n)) return n;
    }
    return "en";
  }

  function getStoredLocale() {
    return new Promise((resolve) => {
      chrome.storage.sync.get({ [STORAGE_KEY]: "auto" }, (cfg) =>
        resolve(cfg[STORAGE_KEY])
      );
    });
  }

  async function getEffectiveLocale() {
    const stored = await getStoredLocale(); // "auto" | "en" | "ja"
    return stored === "auto" ? resolveAutoLocale() : normalizeLocale(stored);
  }

  async function loadMessages(locale) {
    const url = chrome.runtime.getURL(`_locales/${locale}/messages.json`);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Failed to load messages for ${locale}`);
    return res.json();
  }

  function makeTranslator(dict) {
    return (key, fallback = "") => dict[key]?.message ?? (fallback || key);
  }

  function applyToDom(t) {
    // <el data-i18n="key">…</el>
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.getAttribute("data-i18n");
      el.textContent = t(key, el.textContent || "");
    });
    // <el data-i18n-attr="placeholder=key,title=key2">
    document.querySelectorAll("[data-i18n-attr]").forEach((el) => {
      const mapStr = el.getAttribute("data-i18n-attr");
      if (!mapStr) return;
      mapStr.split(",").forEach((pair) => {
        const [attr, key] = pair.split("=").map((s) => s.trim());
        if (!attr || !key) return;
        const cur = el.getAttribute(attr) || "";
        el.setAttribute(attr, t(key, cur));
      });
    });
  }

  async function setLocaleAndApply(locale) {
    currentLocale = locale;
    try {
      messages = await loadMessages(locale);
    } catch {
      messages = await loadMessages("en");
      currentLocale = "en";
    }
    currentT = makeTranslator(messages);
    applyToDom(currentT);
    return currentT;
  }

  // 初期化：storageの言語(=auto含む)を解決して適用
  async function init() {
    const effective = await getEffectiveLocale();
    return setLocaleAndApply(effective);
  }

  // 即時プレビュー用：保存せずにその場で適用（"auto" も可）
  async function applyLocale(localeOrAuto) {
    let loc = localeOrAuto;
    if (!loc || loc === "auto") loc = resolveAutoLocale();
    else loc = normalizeLocale(loc);
    if (!SUPPORTED.includes(loc)) loc = "en";
    return setLocaleAndApply(loc);
  }

  return { init, applyLocale, STORAGE_KEY };
})();
