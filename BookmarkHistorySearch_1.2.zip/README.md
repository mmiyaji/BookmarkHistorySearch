# BookMark & History Search

Chrome Extention

![利用イメージ](screenshot/chrome.png)


検索ボックスからブックマークと履歴を検索するシンプルな拡張機能です
